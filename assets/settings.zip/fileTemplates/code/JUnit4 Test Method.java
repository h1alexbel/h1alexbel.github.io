/**
 * ${CLASS} can work.
 * @throws Exception If fails
 */
@org.junit.Test
public void test${NAME}() throws Exception {
  ${BODY}
}